/*
 * TapeIDSingleton.cc
 *
 *  Created on: Jan 4, 2013
 *      Author: kremer
 */

#include "TapeIDSingleton.hh"

TapeIDSingleton* TapeIDSingleton::reference_ = NULL;
