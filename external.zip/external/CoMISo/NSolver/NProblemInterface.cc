#include "NProblemInterface.hh"

namespace COMISO {

NProblemInterface::NProblemInterface()
{}

NProblemInterface::~NProblemInterface()
{}

}
