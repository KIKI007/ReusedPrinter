// Build time dependencies for CoMiso


#define COMISO_BLAS_AVAILABLE 1
#define COMISO_GMM_AVAILABLE 1
#define COMISO_EIGEN3_AVAILABLE 1
